const CJ_BASE = "https://developers.cjdropshipping.com/api2.0/v1";

const CJ_PRODUCTS = {
  207: { sku: "CJGX195184801AZ", name: "Pendentif cœur pour chat & petit chien — collier perlé" },
  208: { sku: "CJMY200580801AZ", name: "Brosse anti-poils 2-en-1 — vêtements & textiles" }
};

let tokenCache = { value: "", expiresAt: 0 };

function nowIso() { return new Date().toISOString(); }
function cjItems(order) {
  return (order.items || []).filter(item => CJ_PRODUCTS[Number(item.id)]).map(item => ({
    item,
    map: CJ_PRODUCTS[Number(item.id)]
  }));
}
export function orderHasCJItems(order) { return cjItems(order).length > 0; }

async function getAccessToken(force = false) {
  const staticToken = String(process.env.CJ_ACCESS_TOKEN || "").trim();
  if (staticToken) return staticToken;

  const apiKey = String(process.env.CJ_API_KEY || "").trim();
  if (!apiKey) throw new Error("CJ_API_KEY manquante dans Netlify.");

  if (!force && tokenCache.value && tokenCache.expiresAt > Date.now() + 5 * 60_000) return tokenCache.value;

  const res = await fetch(`${CJ_BASE}/authentication/getAccessToken`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ apiKey })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data?.result || !data?.data?.accessToken) {
    throw new Error(data?.message || "Impossible d’obtenir le jeton CJ.");
  }
  const expiry = Date.parse(data.data.accessTokenExpiryDate || "");
  tokenCache = {
    value: data.data.accessToken,
    expiresAt: Number.isFinite(expiry) ? expiry : Date.now() + 12 * 24 * 60 * 60_000
  };
  return tokenCache.value;
}

async function cjFetch(path, { method = "GET", body } = {}, retryAuth = true) {
  const token = await getAccessToken();
  const headers = { "CJ-Access-Token": token, "Content-Type": "application/json" };
  const res = await fetch(`${CJ_BASE}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  const authError = [1600001, 1600002, 1600003, 1600004, 1600005].includes(Number(data?.code));
  if (retryAuth && authError && process.env.CJ_API_KEY) {
    tokenCache = { value: "", expiresAt: 0 };
    await getAccessToken(true);
    return cjFetch(path, { method, body }, false);
  }
  if (!res.ok || data?.result === false) {
    const err = new Error(data?.message || `Erreur CJ (${res.status})`);
    err.cjCode = data?.code;
    throw err;
  }
  return data;
}

export async function fulfillPaidOrderWithCJ(order) {
  if (!order || order.paymentStatus !== "PAID") return order;

  const lines = cjItems(order);
  if (!lines.length) {
    return {
      ...order,
      fulfillmentStatus: order.fulfillmentStatus === "not_started" ? "manual_personalization" : order.fulfillmentStatus,
      cj: order.cj || { status: "not_applicable", updatedAt: nowIso() }
    };
  }

  if (order.cj?.orderId || ["submitted", "UNSHIPPED", "SHIPPED", "DELIVERED"].includes(order.cj?.status)) return order;

  if (!process.env.CJ_API_KEY && !process.env.CJ_ACCESS_TOKEN) {
    return {
      ...order,
      fulfillmentStatus: "cj_configuration_required",
      cj: {
        ...(order.cj || {}),
        status: "configuration_required",
        error: "Ajoutez CJ_API_KEY dans les variables d’environnement Netlify.",
        updatedAt: nowIso()
      }
    };
  }

  const customer = order.customer || {};
  const payType = Number(process.env.CJ_PAY_TYPE || 2);
  const iossType = Number(process.env.CJ_IOSS_TYPE || 3);
  const logisticName = String(process.env.CJ_LOGISTIC_NAME || "CJPacket Ordinary").trim();
  const fromCountryCode = String(process.env.CJ_FROM_COUNTRY_CODE || "CN").trim().toUpperCase();

  const payload = {
    orderNumber: order.id,
    shippingZip: customer.postalCode || "",
    shippingCountry: "France",
    shippingCountryCode: "FR",
    shippingProvince: customer.region || customer.city || "France",
    shippingCity: customer.city || "",
    shippingPhone: customer.phone || "",
    shippingCustomerName: `${customer.firstName || ""} ${customer.lastName || ""}`.trim(),
    shippingAddress: customer.address || "",
    email: customer.email || "",
    remark: `Commande ÉVIDA ${order.id}. Dropshipping direct client. Emballage neutre si disponible.`,
    payType,
    logisticName,
    fromCountryCode,
    platform: "Api",
    shopLogisticsType: 3,
    iossType,
    orderFlow: 1,
    storeOrderTime: Math.floor(Date.parse(order.createdAt || nowIso()) / 1000),
    products: lines.map(({ item, map }) => ({
      sku: map.sku,
      quantity: Math.max(1, Number(item.quantity || 1)),
      storeSku: map.sku,
      storeProductName: map.name,
      storeLineItemId: `${order.id}-${item.id}`
    }))
  };

  try {
    const data = await cjFetch("/shopping/order/createOrderV2", { method: "POST", body: payload });
    const d = data?.data || {};
    return {
      ...order,
      fulfillmentStatus: lines.length === (order.items || []).length ? "supplier_submitted" : "partial_supplier_submitted",
      cj: {
        status: d.orderStatus || "submitted",
        orderId: d.orderId || "",
        shipmentOrderId: d.shipmentOrderId || "",
        orderNumber: d.orderNumber || order.id,
        logisticsName,
        payType,
        actualPaymentUsd: d.actualPayment ?? null,
        productAmountUsd: d.productAmount ?? null,
        postageAmountUsd: d.postageAmount ?? null,
        submittedAt: nowIso(),
        updatedAt: nowIso(),
        error: ""
      }
    };
  } catch (error) {
    return {
      ...order,
      fulfillmentStatus: "cj_error",
      cj: {
        ...(order.cj || {}),
        status: "error",
        error: String(error?.message || "Erreur CJ").slice(0, 500),
        errorCode: error?.cjCode || null,
        updatedAt: nowIso()
      }
    };
  }
}

export async function syncCJOrder(order) {
  if (!order || !orderHasCJItems(order)) return order;
  if (!process.env.CJ_API_KEY && !process.env.CJ_ACCESS_TOKEN) return order;

  try {
    // CJ accepte l'identifiant personnalisé de la boutique dans orderId.
    const data = await cjFetch(`/shopping/order/getOrderDetail?orderId=${encodeURIComponent(order.id)}`);
    const d = data?.data;
    if (!d) return order;

    const status = d.orderStatus || order.cj?.status || "submitted";
    const trackNumber = d.trackNumber || order.trackingNumber || "";
    const trackingUrl = d.trackingUrl || order.trackingUrl || "";
    const carrier = d.trackingProvider || d.logisticName || order.carrier || "";
    const shipped = ["SHIPPED", "DELIVERED"].includes(status);

    return {
      ...order,
      fulfillmentStatus: status === "DELIVERED" ? "delivered" : shipped ? "shipped" : order.fulfillmentStatus,
      trackingNumber: trackNumber,
      trackingUrl,
      carrier,
      cj: {
        ...(order.cj || {}),
        status,
        orderId: d.orderId || order.cj?.orderId || "",
        cjOrderId: d.cjOrderId || d.cjOrderCode || order.cj?.cjOrderId || "",
        logisticsName: d.logisticName || order.cj?.logisticsName || "",
        trackNumber,
        trackingProvider: d.trackingProvider || "",
        orderAmountUsd: d.orderAmount ?? order.cj?.orderAmountUsd ?? null,
        productAmountUsd: d.productAmount ?? order.cj?.productAmountUsd ?? null,
        postageAmountUsd: d.postageAmount ?? order.cj?.postageAmountUsd ?? null,
        updatedAt: nowIso(),
        error: ""
      }
    };
  } catch (error) {
    return {
      ...order,
      cj: {
        ...(order.cj || {}),
        syncError: String(error?.message || "Erreur de synchronisation CJ").slice(0, 500),
        syncErrorAt: nowIso()
      }
    };
  }
}
